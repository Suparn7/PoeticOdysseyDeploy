import React, { useEffect } from 'react';
import './NotificationToast.css'; // You can style it as needed

const NotificationToast = ({ message, type, onClose }) => {
    useEffect(() => {
        const timer = setTimeout(() => {
            onClose();
        }, 1000); // Auto close after 1 second

        return () => clearTimeout(timer);
    }, [onClose]);

    return (
        <div className={`notification ${type} absolute top-4 right-4 z-100`} onClick={onClose}>
            {message}
        </div>
    );
};

export default NotificationToast;
