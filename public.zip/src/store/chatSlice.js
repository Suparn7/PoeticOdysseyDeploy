import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    messages: [],      // Array to store chat messages
    loading: false,    // Loading state for fetching messages
    error: null,       // Error state for managing errors
};

const chatSlice = createSlice({
    name: 'chat',
    initialState,
    reducers: {
        setMessages: (state, action) => {
            state.messages = action.payload;  // Store fetched messages
        },
        addMessage: (state, action) => {
            state.messages.push(action.payload);  // Add a new message to the state
        },
        deleteMessage: (state, action) => {
            const messageId = action.payload;
            state.messages = state.messages.filter(msg => msg.timestamp !== messageId);  // Remove the message from state
        },
        setLoading: (state, action) => {
            state.loading = action.payload;  // Set loading state
        },
        setError: (state, action) => {
            state.error = action.payload;  // Set error state
        },
    },
});

export const { setMessages, addMessage, deleteMessage, setLoading, setError } = chatSlice.actions;

export default chatSlice.reducer;
