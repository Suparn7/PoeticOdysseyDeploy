import { createSlice } from '@reduxjs/toolkit';

// Initial state for user information with new attributes
const initialState = {
  userId: null,
  email: '',
  phone: '',
  passwordHash: '',
  name: '',
  profilePicUrl: '',
  createdAt: null,
  updatedAt: null,
  likedPosts: [],
  savedPosts: [],
  postsCreated: [],
  isVerified: false,
  isAdmin: false,
  bio: '',
  loading: false,
  error: null,
};

// User information slice
const userInformationSlice = createSlice({
  name: 'userInformation',
  initialState,
  reducers: {
    // Action to set user data
    setUserInformation: (state, action) => {
      const {
        userId,
        email,
        phone,
        passwordHash,
        name,
        profilePicUrl,
        createdAt,
        updatedAt,
        likedPosts,
        savedPosts,
        postsCreated,
        isVerified,
        isAdmin,
        bio,
      } = action.payload;
      
      state.userId = userId;
      state.email = email;
      state.phone = phone;
      state.passwordHash = passwordHash;
      state.name = name;
      state.profilePicUrl = profilePicUrl;
      state.createdAt = createdAt;
      state.updatedAt = updatedAt;
      state.likedPosts = likedPosts || [];
      state.savedPosts = savedPosts || [];
      state.postsCreated = postsCreated || [];
      state.isVerified = isVerified || false;
      state.isAdmin = isAdmin || false;
      state.bio = bio || '';
    },
    
    // Action to update user data
    updateUserInformation: (state, action) => {
      const { name, email, phone, profilePicUrl, bio } = action.payload;
      if (name) state.name = name;
      if (email) state.email = email;
      if (phone) state.phone = phone;
      if (profilePicUrl) state.profilePicUrl = profilePicUrl;
      if (bio) state.bio = bio;
    },
    
    // Action to set loading state
    setLoading: (state, action) => {
      state.loading = action.payload;
    },
    
    // Action to handle errors
    setError: (state, action) => {
      state.error = action.payload;
    },
    
    // Clear user data
    clearUserInformation: () => initialState,
  },
});

export const { 
  setUserInformation, 
  updateUserInformation, 
  setLoading, 
  setError, 
  clearUserInformation 
} = userInformationSlice.actions;

export default userInformationSlice.reducer;
