import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import authService from '../../appwrite/auth';
import { logout } from '../../store/authSlice';
import { useNavigate } from 'react-router-dom';
import { persistor } from '../../store/store'; // Import persistor from store

const LogoutBtn = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const [showConfirm, setShowConfirm] = useState(false); // State for confirmation modal

    const logoutHandler = () => {
        setShowConfirm(true); // Show confirmation modal
    };

    const confirmLogout = async () => {
        await authService.logout();
        dispatch(logout());
        persistor.purge();
        navigate("/login");
    };

    const cancelLogout = () => {
        setShowConfirm(false); // Close confirmation modal
    };

    return (
        <div className="relative">
            {showConfirm && (
                <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
                    <div className="bg-gray-800 text-white rounded-lg p-6 shadow-lg">
                        <h2 className="text-lg font-bold mb-4">Are you sure you want to logout?</h2>
                        <div className="flex justify-between">
                            <button 
                                onClick={confirmLogout} 
                                className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded"
                            >
                                Yes, Logout
                            </button>
                            <button 
                                onClick={cancelLogout} 
                                className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded"
                            >
                                No, Stay
                            </button>
                        </div>
                    </div>
                </div>
            )}
            <button 
                className='inline-block px-6 py-2 text-white bg-red-600 rounded-full shadow-lg transition duration-300 transform hover:bg-red-700 hover:scale-105 hover:shadow-xl' 
                onClick={logoutHandler}
            >
                Logout
            </button>


            {/* CSS for animations */}
            <style jsx>{`
                @keyframes fadeIn {
                    from {
                        opacity: 0;
                        transform: translateY(-20px);
                    }
                    to {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }
            `}</style>
        </div>
    );
}

export default LogoutBtn;
