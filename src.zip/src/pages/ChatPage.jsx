import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { setMessages, addMessage, deleteMessage, setLoading, setError } from '../store/chatSlice';
import service from '../appwrite/config';
import { useParams } from 'react-router-dom';

const ChatPage = () => {
    const dispatch = useDispatch();
    const { chatId } = useParams();  // Get chatId from URL params
    const messages = useSelector((state) => state.chat.messages);
    const [newMessage, setNewMessage] = useState('');
    
    // Fetch messages when the component mounts
    useEffect(() => {
        const fetchMessages = async () => {
            dispatch(setLoading(true));
            try {
                const fetchedMessages = await service.getChatMessages(chatId);
                dispatch(setMessages(fetchedMessages));
            } catch (error) {
                dispatch(setError('Error fetching messages'));
            } finally {
                dispatch(setLoading(false));
            }
        };

        fetchMessages();

        // Subscribe to new messages in real-time
        service.subscribeToChatMessages(chatId, (newMsg) => {
            dispatch(addMessage(newMsg));  // Add new message to Redux store
        });

    }, [chatId, dispatch]);

    // Handle sending new message
    const handleSendMessage = async () => {
        if (newMessage.trim()) {
            const messageData = {
                chatId,
                senderId: 'user_id',  // Replace with actual logged-in user ID
                messageText: newMessage,
                timestamp: new Date().toISOString(),
            };

            try {
                await service.sendMessage(messageData);  // Send message to Appwrite
                dispatch(addMessage(messageData));  // Add to Redux store immediately
                setNewMessage('');
            } catch (error) {
                console.log('Error sending message:', error);
            }
        }
    };

    // Handle deleting a message
    const handleDeleteMessage = async (messageId) => {
        try {
            const success = await service.deleteMessage(chatId, messageId);  // Delete from Appwrite
            if (success) {
                dispatch(deleteMessage(messageId));  // Remove from Redux store
            } else {
                dispatch(setError('Error deleting message'));
            }
        } catch (error) {
            console.log('Error deleting message:', error);
            dispatch(setError('Error deleting message'));
        }
    };

    return (
        <div className="chat-page">
            <div className="messages">
                {messages.map((msg) => (
                    <div key={msg.timestamp} className="message">
                        <strong>{msg.senderId}</strong>: {msg.messageText}
                        <button onClick={() => handleDeleteMessage(msg.timestamp)}>Delete</button> {/* Delete button */}
                    </div>
                ))}
            </div>
            <div className="input-section">
                <input
                    type="text"
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder="Type a message..."
                />
                <button onClick={handleSendMessage}>Send</button>
            </div>
        </div>
    );
};

export default ChatPage;
