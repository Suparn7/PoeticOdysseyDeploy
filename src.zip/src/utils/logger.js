// src/utils/logger.js

import log from 'loglevel';

// Set the default log level (can be 'trace', 'debug', 'info', 'warn', 'error', 'silent')
log.setDefaultLevel('info');

// Optional: Custom logger functions
const logger = {
    info: (message) => log.info(message),
    warn: (message) => log.warn(message),
    error: (message) => log.error(message),
    debug: (message) => log.debug(message),
};

export default logger;
