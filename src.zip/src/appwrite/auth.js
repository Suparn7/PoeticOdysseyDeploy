import { Client, Account, ID } from "appwrite";
import conf from "../conf/conf";

export class AuthService {
    client = new Client();
    account;

    constructor() {
        this.client.setEndpoint(conf.appwriteUrl).setProject(conf.appwriteProjectId);
        this.account = new Account(this.client);
    }

    async createAccount({ email, password, name }) {
        try {
            const userAccount = await this.account.create(ID.unique(), email, password, name);
            
            if (userAccount) {
                console.log("inside if of create account");
                return this.login({ email, password });
            } else {
                return userAccount;
            }
        } catch (error) {
            throw error;
        }
    }

    async login({ email, password }) {
        try {
            return await this.account.createEmailPasswordSession(email, password);
        } catch (error) {
            throw error;
        }
    }

    async getCurrentUser() {
        try {
            return this.account.get();
        } catch (error) {
            console.log("Appwrite service :: getCurrentUser() ::", error);
        }
        return null;
    }

    async logout() {
        try {
            await this.account.deleteSessions();
        } catch (error) {
            console.log("Appwrite service :: logout() ::", error);
        }
    }

    async fetchUserById(userId) {
        try {
            const response = await fetch(`${conf.appwriteUrl}/users/${userId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Appwrite-Project': conf.appwriteProjectId,
                    'X-Appwrite-Key': conf.adminApiKey,
                },
            });
    
            if (!response.ok) {
                throw new Error(`Error fetching user: ${response.statusText}`);
            }
    
            const user = await response.json();
            
            return user; // Return the user object
        } catch (error) {
            console.error('Error fetching user:', error.message);
            throw error; // Re-throw error for handling in caller
        }
    }
    
    
    
}

// Initialize the AuthService instance
const authService = new AuthService();

export default authService;
