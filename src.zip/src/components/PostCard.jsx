import React, { useState, useEffect } from 'react';
import { Link } from "react-router-dom";
import parse from 'html-react-parser';
import appWriteService from '../appwrite/config';
import authService from '../appwrite/auth';
import '../styles/loader.css'; // Import the CSS file for loader styles

const PostCard = ({ $id, title, content, featuredImage, userId }) => {
  const [author, setAuthor] = useState('');
  const [loading, setLoading] = useState(true); // Add loading state
  const [fadeOut, setFadeOut] = useState(false); // New state for fade out
  const [isDarkTheme, setIsDarkTheme] = useState(true); // State to manage theme for each card

  useEffect(() => {
    const fetchAuthor = async () => {
      try {
        const user = await authService.fetchUserById(userId);
        setAuthor(user.name); // Set the author's name in state
      } catch (error) {
        console.error("Failed to fetch author:", error);
      } finally {
        setFadeOut(true); // Start fade out effect
        setTimeout(() => setLoading(false), 500); // Delay to allow fade out to complete
      }
    };

    fetchAuthor();
  }, [userId]);

  // Toggle the theme for this card
  const toggleTheme = () => {
    setIsDarkTheme(!isDarkTheme);
  };

  return (
    <>
      {/* Define the animations and styles inline */}
      <style>
        {`
          @keyframes borderGlow {
            0% {
              border-color: #3498db;  /* Light Blue Glow */
              box-shadow: 0 0 5px #3498db, 0 0 10px #3498db;
            }
            50% {
              border-color: #1abc9c;  /* Light Green Glow */
              box-shadow: 0 0 15px #1abc9c, 0 0 30px #1abc9c;
            }
            100% {
              border-color: #3498db;  /* Light Blue Glow */
              box-shadow: 0 0 5px #3498db, 0 0 10px #3498db;
            }
          }

          @keyframes cardAnimation {
            0% {
              transform: scale(0.95);
              opacity: 0;
            }
            100% {
              transform: scale(1);
              opacity: 1;
            }
          }

          @keyframes fadeIn {
            0% {
              opacity: 0;
            }
            100% {
              opacity: 1;
            }
          }
        `}
      </style>

      <div
        style={{
          background: isDarkTheme
            ? 'linear-gradient(135deg, rgba(0, 0, 0, 0.4) 0%, rgba(0, 0, 0, 0.7) 100%)'
            : 'linear-gradient(135deg, rgba(255, 255, 255, 0.8) 0%, rgba(240, 240, 240, 0.7) 100%)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          borderRadius: '20px',
          padding: '25px',
          color: isDarkTheme ? 'white' : 'black',
          transition: 'transform 0.4s, box-shadow 0.4s, opacity 0.4s, background 0.5s ease',
          position: 'relative',
          overflow: 'hidden',
          textAlign: 'center',
          height: '500px',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'flex-end',
          boxShadow: isDarkTheme ? '0 15px 30px rgba(0, 0, 0, 0.2)' : '0 15px 30px rgba(200, 200, 200, 0.3)',
          border: '3px solid #3498db', // Always use a blueish border glow
          animation: 'cardAnimation 1s ease-out, borderGlow 1.5s ease-in-out infinite', // Adding border glow animation
        }}
        className="post-card"
        onMouseEnter={(e) => {
          e.currentTarget.style.transform = 'scale(1.05)';
          e.currentTarget.style.boxShadow = '0 15px 45px rgba(0, 0, 0, 0.4)';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.transform = 'scale(1)';
          e.currentTarget.style.boxShadow = '0 15px 30px rgba(0, 0, 0, 0.2)';
        }}
      >
        {/* Theme Toggle Button */}
        <button
          onClick={toggleTheme}
          style={{
            position: 'absolute',
            top: '15px',
            right: '15px',
            backgroundColor: isDarkTheme ? 'white' : '#333',
            color: isDarkTheme ? '#333' : 'white',
            border: 'none',
            borderRadius: '50%',
            padding: '10px',
            cursor: 'pointer',
            fontSize: '18px',
            zIndex: 10, // Ensure button stays on top
            boxShadow: '0 4px 10px rgba(0, 0, 0, 0.2)',
            transition: 'background-color 0.3s ease, color 0.3s ease',
          }}
        >
          🌙
        </button>

        {loading && (
          <div className={`loader-overlay ${fadeOut ? 'hidden' : ''}`}>
            <div className="loader-container">
              <div className="loader"></div>
              <h2 className="loading-text">Loading post...</h2>
            </div>
          </div>
        )}

        <Link
          to={`/post/${$id}`}
          style={{
            textDecoration: 'none',
            color: 'inherit',
            display: 'flex',
            flexDirection: 'column',
            height: '100%',
          }}
        >
          {/* Image Container with fixed width and height */}
          <div
            style={{
              width: '100%',
              height: '300px', // Fixed height and width for image
              overflow: 'hidden',
              borderRadius: '15px',
              boxShadow: isDarkTheme
                ? '0 10px 40px rgba(0, 0, 0, 0.5)'
                : '0 10px 40px rgba(200, 200, 200, 0.3)',
              transition: 'box-shadow 0.3s ease-in-out',
              zIndex: 1, // Ensure image stays behind the toggle button
            }}
          >
            <img
              src={appWriteService.getFilePreview(featuredImage)}
              alt={title}
              style={{
                width: '100%', // Fixed width
                height: '100%', // Fixed height
                objectFit: 'cover', // Ensure the image fills the box properly
                borderRadius: '15px',
                transition: 'transform 0.3s ease-in-out',
              }}
              onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.05)'}
              onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
            />
          </div>

          {/* Title */}
          <h2
            style={{
              fontSize: '1.5rem',
              fontWeight: 'bold',
              margin: '15px 0 5px',
              textTransform: 'uppercase',
              letterSpacing: '1.2px',
              background: isDarkTheme ? 'rgba(255, 255, 255, 0.15)' : 'rgba(0, 0, 0, 0.1)',
              padding: '12px 20px',
              borderRadius: '8px',
              overflow: 'hidden',
              textOverflow: 'ellipsis', // Truncate long titles
              whiteSpace: 'nowrap', // Prevent title from breaking onto new line
              animation: 'fadeIn 1s ease-out',
              opacity: fadeOut ? 1 : 0,
              textShadow: isDarkTheme ? '1px 1px 5px rgba(0, 0, 0, 0.7)' : '1px 1px 5px rgba(200, 200, 200, 0.7)',
            }}
          >
            {title}
          </h2>

          {/* Author */}
          <div
            style={{
              fontSize: '1rem',
              color: isDarkTheme ? '#f1c40f' : '#555', // Softer gold for dark theme, gray for light
              marginBottom: '12px',
              opacity: fadeOut ? 1 : 0,
              transition: 'opacity 0.5s ease-in-out',
              textShadow: isDarkTheme ? '1px 1px 3px rgba(0, 0, 0, 0.5)' : '1px 1px 3px rgba(200, 200, 200, 0.5)', // Adjust text shadow
            }}
          >
            {author}
          </div>

          {/* Content */}
          <div
            style={{
              fontSize: '1rem',
              color: isDarkTheme ? '#dcdcdc' : '#111',
              lineHeight: '1.5',
              background: isDarkTheme ? 'rgba(255, 255, 255, 0.15)' : 'rgba(0, 0, 0, 0.1)',
              borderRadius: '8px',
              padding: '15px',
              height: '80px', // Fixed height for content area
              overflow: 'hidden',
              textAlign: 'center',
              wordWrap: 'break-word',
              textOverflow: 'ellipsis', // Truncate overflowed content
              opacity: fadeOut ? 1 : 0,
              animation: 'fadeIn 1s ease-out',
            }}
          >
            {parse(content.length > 100 ? `${content.substring(0, 100)}...` : content)}
          </div>

          {/* Read More Link */}
          <div
            style={{
              fontSize: '1rem',
              color: isDarkTheme ? '#f1c40f' : '#000',
              textDecoration: 'underline',
              cursor: 'pointer',
              marginTop: '18px',
              transition: 'color 0.3s ease',
              opacity: fadeOut ? 1 : 0,
              animation: 'fadeIn 1s ease-out',
            }}
          >
            Read More
          </div>
        </Link>
      </div>
    </>
  );
};

export default PostCard;
