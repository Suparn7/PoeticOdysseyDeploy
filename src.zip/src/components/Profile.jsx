import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { Link } from 'react-router-dom';
import { setUserData } from '../store/userSlice';
import userService from '../appwrite/userService';
import logo from "../images/Logo.png";
import conf from '../conf/conf';

// Importing FontAwesome icons
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEdit, faPhone, faEnvelope, faCamera, faHeart, faBookmark, faBan, faFloppyDisk } from '@fortawesome/free-solid-svg-icons';

const Profile = () => {
    const dispatch = useDispatch();
    const userData = useSelector((state) => state.auth.userData);
    const userInfoData = useSelector((state) => state.user.userData);
    const [isEditing, setIsEditing] = useState(false);
    const [name, setName] = useState(userInfoData?.name || '');
    const [bio, setBio] = useState(userInfoData?.bio || '');
    const [email, setEmail] = useState(userInfoData?.email || '');
    const [phone, setPhone] = useState(userInfoData?.phone || '');
    const [profilePic, setProfilePic] = useState(null);
    const [profilePicUrl, setProfilePicUrl] = useState(userInfoData?.profilePicUrl || logo);

    useEffect(() => {
        if (userInfoData) {
            setName(userInfoData.name);
            setBio(userInfoData.bio);
            setEmail(userInfoData.email);
            setPhone(userInfoData.phone);
            setProfilePicUrl(userInfoData.profilePicUrl || logo); // Initial profilePicUrl
        }
    }, [userInfoData]);

    const handleNameChange = (e) => setName(e.target.value);
    const handleBioChange = (e) => setBio(e.target.value);
    const handleEmailChange = (e) => setEmail(e.target.value);
    const handlePhoneChange = (e) => setPhone(e.target.value);

    const handleProfilePicChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            // Create a temporary URL for the selected image to preview it immediately
            const imageUrl = URL.createObjectURL(file);
            setProfilePic(file); // Save the file to state for upload
            setProfilePicUrl(imageUrl); // Set the temporary URL to show the new image
        }
    };

    const saveProfile = async () => {
        if (profilePic) {
            const imgDetails = await userService.uploadFile(profilePic);
            if (imgDetails) {
                const imageUrl = `${conf.appwriteUrl}/storage/buckets/${imgDetails.bucketId}/files/${imgDetails.$id}/view?project=${conf.appwriteProjectId}`;
                await userService.updateUser(userInfoData.userId, { name, bio, profilePicUrl: imageUrl, email, phone });
                dispatch(setUserData({ ...userInfoData, profilePicUrl: imageUrl, name, bio, email, phone }));
            }
        } else {
            await userService.updateUser(userInfoData.userId, { name, bio, email, phone });
            dispatch(setUserData({ ...userInfoData, name, bio, email, phone }));
        }
        setIsEditing(false);
    };

    if (!userInfoData) {
        return <div className="container mx-auto p-4">No user data found.</div>;
    }

    return (
        <div className="flex justify-center items-center min-h-screen ">
            <div className="bg-gradient-to-r from-blue-200 via-indigo-300 to-blue-100 rounded-lg shadow-xl p-6 w-full max-w-lg overflow-x-hidden transform transition-all duration-500 hover:scale-105 hover:shadow-2xl relative shadow-lg">
                
                {/* Edit Profile Button in the top-right corner */}
                {!isEditing && (
                    <button
                        onClick={() => setIsEditing(true)}
                        className="absolute top-4 right-4 bg-yellow-500 hover:bg-yellow-600 text-white font-semibold py-2 px-4 rounded-lg shadow-lg flex items-center space-x-2 transform transition-all duration-300 hover:scale-110 hover:shadow-2xl hover:animate-bounce"
                    >
                        <FontAwesomeIcon icon={faEdit} className="text-lg" />
                        <span>Edit Profile</span>
                    </button>
                )}

                {/* Icons for save or cancel changes */}
                {isEditing && (
                    <div className="absolute top-4 right-4 flex items-center space-x-4">
                        {/* Save Icon */}
                        <button
                            onClick={saveProfile}
                            className="flex items-center justify-center p-2 bg-gradient-to-r from-indigo-400 via-indigo-500 to-indigo-600 text-white rounded-full shadow-lg transition duration-300 transform hover:scale-110 hover:shadow-2xl focus:outline-none hover:animate-bounce"
                        >
                            <FontAwesomeIcon icon={faFloppyDisk} className="text-xl" />
                            <span className="ml-1 text-xs font-semibold">Save</span>
                        </button>
                        
                        {/* Cancel Icon */}
                        <button
                            onClick={() => setIsEditing(false)}
                            className="flex items-center justify-center p-2 bg-gradient-to-r from-red-400 via-red-500 to-red-600 text-white rounded-full shadow-lg transition duration-300 transform hover:scale-110 hover:shadow-2xl focus:outline-none hover:animate-bounce"
                        >
                            <FontAwesomeIcon icon={faBan} className="text-xl" />
                            <span className="ml-1 text-xs font-semibold">Cancel</span>
                        </button>
                    </div>
                )}

                <div className="flex flex-col items-center space-y-6 w-full">

                    {/* Profile Picture with upload icon */}
                    <div className="relative">
                        <img
                            src={profilePicUrl}
                            alt="Profile"
                            className="w-32 h-32 rounded-full border-4 border-indigo-500 shadow-lg transform transition-transform duration-300 hover:scale-110 hover:rotate-6 hover:shadow-2xl hover:animate-spin-slow"
                        />
                        {isEditing && (
                            <label htmlFor="profilePicUpload" className="absolute bottom-0 right-0 bg-indigo-500 rounded-full p-2 cursor-pointer shadow-lg hover:opacity-100 transition-all duration-300 hover:scale-125">
                                <FontAwesomeIcon icon={faCamera} className="text-white text-xl" />
                            </label>
                        )}
                        <input
                            type="file"
                            id="profilePicUpload"
                            onChange={handleProfilePicChange}
                            className="hidden"
                        />
                    </div>

                    {/* Name Section - Moved Above Bio */}
                    <div className="text-center w-full mt-4">
                        {isEditing ? (
                            <input
                                type="text"
                                value={name}
                                onChange={handleNameChange}
                                className="text-2xl font-semibold text-gray-800 bg-transparent border-b-2 border-indigo-500 p-2 focus:outline-none focus:ring-2 focus:ring-indigo-400 w-full transform transition duration-300 hover:scale-105"
                            />
                        ) : (
                            <h1 className="text-3xl font-bold text-gray-800 animate__animated animate__fadeIn">{name}</h1>
                        )}
                    </div>

                    {/* Bio Section below Name */}
                    <div className="w-full bg-gradient-to-r from-indigo-50 via-indigo-100 to-indigo-200 rounded-lg p-4 shadow-lg transform transition-all duration-300 hover:scale-105 hover:shadow-2xl hover:bg-gradient-to-l hover:from-indigo-100 hover:via-indigo-200 hover:to-indigo-300 shadow-xl">
                        {isEditing ? (
                            <textarea
                                value={bio}
                                onChange={handleBioChange}
                                className="text-md text-gray-700 bg-transparent border-2 border-indigo-500 p-2 focus:outline-none focus:ring-2 focus:ring-indigo-400 w-full h-24 resize-none overflow-y-auto rounded-lg transition duration-300 hover:scale-105"
                                style={{ maxHeight: "150px" }} // Limit height and allow scrolling
                            />
                        ) : (
                            <div className="max-h-48 overflow-y-auto">
                                <p className="text-md text-gray-700 break-words">
                                    {bio}
                                </p>
                            </div>
                        )}
                    </div>

                    {/* Liked & Saved Posts (below Name) with Cool Animated Buttons */}
                    {!isEditing && (
                        <div className="mt-6 flex space-x-6 w-full">
                            <Link to="/liked-posts" className="w-full">
                                <button className="w-full bg-red-600 text-white font-semibold py-2 px-4 rounded-lg shadow-lg transform transition-all duration-300 hover:scale-110 hover:bg-red-700 hover:shadow-2xl hover:translate-y-1 hover:animate-pulse">
                                    <FontAwesomeIcon icon={faHeart} className="text-2xl mr-2" />
                                    Liked Posts
                                </button>
                            </Link>
                            <Link to="/saved-posts" className="w-full">
                                <button className="w-full bg-blue-600 text-white font-semibold py-2 px-4 rounded-lg shadow-lg transform transition-all duration-300 hover:scale-110 hover:bg-blue-700 hover:shadow-2xl hover:translate-y-1 hover:animate-pulse">
                                    <FontAwesomeIcon icon={faBookmark} className="text-2xl mr-2" />
                                    Saved Posts
                                </button>
                            </Link>
                        </div>
                    )}

                    {/* Contact Info Section */}
                    <div className="bg-gradient-to-r from-teal-200 via-indigo-50 to-blue-300 rounded-lg shadow-xl p-6 w-full mt-6 transform transition-all duration-300 hover:scale-105 hover:shadow-2xl shadow-xl">
                        <h2 className="text-xl font-semibold text-gray-800 mb-4 animate__animated animate__fadeInUp">Contact Information</h2>

                        {/* Editable Email */}
                        {isEditing ? (
                            <div className="flex items-center space-x-2 mb-4">
                                <FontAwesomeIcon icon={faEnvelope} className="text-indigo-500 text-2xl" />
                                <input
                                    type="email"
                                    value={email}
                                    onChange={handleEmailChange}
                                    className="text-lg text-gray-700 bg-transparent border-2 border-indigo-500 p-2 focus:outline-none focus:ring-2 focus:ring-indigo-400 w-full rounded-lg transform transition duration-300 hover:scale-105"
                                />
                            </div>
                        ) : (
                            <p className="text-lg text-gray-700 flex items-center mb-4">
                                <FontAwesomeIcon icon={faEnvelope} className="mr-2 text-indigo-500" />
                                {email}
                            </p>
                        )}

                        {/* Editable Phone */}
                        {isEditing ? (
                            <div className="flex items-center space-x-2 mb-4">
                                <FontAwesomeIcon icon={faPhone} className="text-indigo-500 text-2xl" />
                                <input
                                    type="tel"
                                    value={phone}
                                    onChange={handlePhoneChange}
                                    className="text-lg text-gray-700 bg-transparent border-2 border-indigo-500 p-2 focus:outline-none focus:ring-2 focus:ring-indigo-400 w-full rounded-lg transform transition duration-300 hover:scale-105"
                                />
                            </div>
                        ) : (
                            <p className="text-lg text-gray-700 flex items-center mb-4">
                                <FontAwesomeIcon icon={faPhone} className="mr-2 text-indigo-500" />
                                {phone}
                            </p>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Profile;
