import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faFacebook, faTwitter, faLinkedin, faWhatsapp } from '@fortawesome/free-brands-svg-icons'; // Corrected import
import { faShareAlt } from '@fortawesome/free-solid-svg-icons'; // This is the share icon from the solid set
import Button from './Button'; // Assuming you have a custom Button component

const ShareButtons = ({ post }) => {
  const [isExpanded, setIsExpanded] = useState(false); // State to control icon visibility
  const { title, $id } = post; // Destructure the title and $id from the post object
  const encodePostTitle = encodeURIComponent(title);  // Only encode the title
  const postUrl = `https://easysharesuparn7.netlify.app/`;  // Construct the post URL (no encoding yet)
  const encodePostUrl = encodeURIComponent(postUrl);  // Only encode the post URL once

  // URLs for sharing the post on different platforms
  const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodePostUrl}`;
  const twitterUrl = `https://twitter.com/intent/tweet?text=${encodePostTitle}&url=${encodePostUrl}`;
  const linkedinUrl = `https://www.linkedin.com/shareArticle?mini=true&url=${encodePostUrl}&title=${encodePostTitle}`;
  const whatsappUrl = `https://wa.me/?text=${encodePostTitle}%20${encodePostUrl}`;

  const handleToggleShare = () => {
    setIsExpanded(prev => !prev); // Toggle the visibility of icons
  };

  return (
    <div className="relative flex justify-center mt-4">
      {/* Share Button */}
      <Button
        onClick={handleToggleShare}
        className="p-4 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-full shadow-xl hover:from-pink-500 hover:via-purple-600 hover:to-blue-400 transition duration-300 ease-in-out transform hover:scale-110 animate-pulse"
      >
        <FontAwesomeIcon icon={faShareAlt} className="text-white text-2xl" />
      </Button>

      {/* Share Icons Container */}
      <div
        className={`absolute top-0 left-0 flex flex-col items-center space-y-3 mt-10 transition-all duration-500 ease-in-out transform ${
          isExpanded ? 'opacity-100 scale-100' : 'opacity-0 scale-0 pointer-events-none'
        }`}
      >
        {/* Facebook Share Button */}
        <a href={facebookUrl} target="_blank" rel="noopener noreferrer">
          <Button className="p-4 bg-blue-600 rounded-full shadow-lg hover:bg-blue-700 transition-all duration-300 transform hover:rotate-12 hover:scale-110 hover:shadow-2xl animate-pulse hover:text-yellow-400">
            <FontAwesomeIcon icon={faFacebook} className="text-white text-3xl" />
          </Button>
        </a>

        {/* Twitter Share Button */}
        <a href={twitterUrl} target="_blank" rel="noopener noreferrer">
          <Button className="p-4 bg-blue-400 rounded-full shadow-lg hover:bg-blue-500 transition-all duration-300 transform hover:rotate-12 hover:scale-110 hover:shadow-2xl animate-pulse hover:text-yellow-400">
            <FontAwesomeIcon icon={faTwitter} className="text-white text-3xl" />
          </Button>
        </a>

        {/* LinkedIn Share Button */}
        <a href={linkedinUrl} target="_blank" rel="noopener noreferrer">
          <Button className="p-4 bg-blue-700 rounded-full shadow-lg hover:bg-blue-800 transition-all duration-300 transform hover:rotate-12 hover:scale-110 hover:shadow-2xl animate-pulse hover:text-yellow-400">
            <FontAwesomeIcon icon={faLinkedin} className="text-white text-3xl" />
          </Button>
        </a>

        {/* WhatsApp Share Button */}
        <a href={whatsappUrl} target="_blank" rel="noopener noreferrer">
          <Button className="p-4 bg-green-500 rounded-full shadow-lg hover:bg-green-600 transition-all duration-300 transform hover:rotate-12 hover:scale-110 hover:shadow-2xl animate-pulse hover:text-yellow-400">
            <FontAwesomeIcon icon={faWhatsapp} className="text-white text-3xl" />
          </Button>
        </a>
      </div>
    </div>
  );
};

export default ShareButtons;
