import Login from './Login'
import SignUp from './Signup'
import Profile from './Profile'

export {
    Login,
    SignUp,
    Profile
}