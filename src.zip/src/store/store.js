// store.js
import { configureStore, getDefaultMiddleware  } from '@reduxjs/toolkit';
import { persistStore, persistReducer } from 'redux-persist';
import storage from 'redux-persist/lib/storage'; // Default is localStorage
import authSlice from './authSlice';
import postSlice from './postSlice';
import notificationSlice from './notificationSlice';
import chatSlice from './chatSlice';
import userSlice from './userSlice';

// Persist configuration for the user slice
const persistConfig = {
  key: 'user', // The key where the persisted data will be stored
  storage, // Uses localStorage by default
  whitelist: ['userData', 'likedPosts', 'savedPosts'], // Specify which parts of the user slice to persist
};

// Persisted reducer for the user slice
const persistedUserReducer = persistReducer(persistConfig, userSlice);

const store = configureStore({
  reducer: {
    auth: authSlice,
    posts: postSlice,
    notifications: notificationSlice,
    chat: chatSlice,
    user: persistedUserReducer, // Persist the user reducer
  },
  // Disable serializability check for redux-persist actions
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActions: ['persist/PURGE', 'persist/REHYDRATE', 'persist/FLUSH', 'persist/REGISTER'], // Ignore persist actions
        ignoredPaths: ['persist', 'user'], // Optional: Ignore specific parts of state if needed
      },
    }),
});

const persistor = persistStore(store); // Create the persistor to manage the persistence

export { store, persistor };
